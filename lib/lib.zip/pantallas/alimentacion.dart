import 'package:flutter/material.dart';
import 'package:mi_app/servicios/alimentacion_service.dart';

class PantallaAlimentacion extends StatefulWidget {
  const PantallaAlimentacion({super.key});

  @override
  State<PantallaAlimentacion> createState() => _PantallaAlimentacionState();
}

class _PantallaAlimentacionState extends State<PantallaAlimentacion> {
  final formulario = GlobalKey<FormState>();
  final edadController = TextEditingController();
  final entrenamientoController = TextEditingController();
  final preferenciasController = TextEditingController();
  final alergiasController = TextEditingController();
  int dias = 7;
  bool cargando = false;
  String? error;
  List<Map<String, String>> plan = [];

  @override
  void dispose() {
    edadController.dispose();
    entrenamientoController.dispose();
    preferenciasController.dispose();
    alergiasController.dispose();
    super.dispose();
  }

  Future<void> generarPlan() async {
    if (!formulario.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    setState(() {
      cargando = true;
      error = null;
      plan = [];
    });
    try {
      final resultado = await AlimentacionService().generarPlan({
        'edad': int.parse(edadController.text.trim()),
        'entrenamiento': entrenamientoController.text.trim(),
        'preferencias': preferenciasController.text.trim(),
        'alergias': alergiasController.text.trim(),
        'dias': dias,
      });
      if (!mounted) return;
      setState(() => plan = resultado);
    } catch (e) {
      if (!mounted) return;
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => cargando = false);
    }
  }

  Widget campo(TextEditingController controller, String etiqueta) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: TextFormField(
        controller: controller,
        enabled: !cargando,
        maxLength: 400,
        decoration: InputDecoration(
          labelText: etiqueta,
          border: const OutlineInputBorder(),
        ),
        validator: (valor) => valor == null || valor.trim().isEmpty
            ? 'Completa este campo; puedes escribir "Ninguna".'
            : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Alimentación para corredores'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(25),
        child: Form(
          key: formulario,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Tu brief de alimentación',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 15),
              const Text(
                'Para corredores amateur adultos. El plan comienza '
                'el lunes y cubre hasta una semana. Tus respuestas se envían '
                'al servidor y a OpenAI al generar el plan.',
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: edadController,
                enabled: !cargando,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Edad',
                  border: OutlineInputBorder(),
                ),
                validator: (valor) {
                  final edad = int.tryParse(valor?.trim() ?? '');
                  return edad == null || edad < 18 || edad > 100
                      ? 'Ingresa una edad entre 18 y 100 años.'
                      : null;
                },
              ),
              const SizedBox(height: 15),
              campo(
                entrenamientoController,
                'Entrenamiento: días, duración y horario',
              ),
              campo(
                preferenciasController,
                'Preferencias, objetivo y presupuesto',
              ),
              campo(
                alergiasController,
                'Alergias o restricciones alimentarias',
              ),
              DropdownButtonFormField<int>(
                initialValue: dias,
                decoration: const InputDecoration(
                  labelText: 'Días del plan',
                  border: OutlineInputBorder(),
                ),
                items: List.generate(
                  7,
                  (index) => DropdownMenuItem(
                    value: index + 1,
                    child: Text('${index + 1} días'),
                  ),
                ),
                onChanged: cargando
                    ? null
                    : (valor) {
                        setState(() => dias = valor!);
                      },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: cargando ? null : generarPlan,
                child: Text(
                  cargando ? 'Generando...' : 'Generar plan con ChatGPT',
                ),
              ),
              if (cargando) const Center(child: CircularProgressIndicator()),
              if (error != null)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  child: Text(
                    error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                ),
              if (plan.isNotEmpty) ...[
                const SizedBox(height: 20),
                const Text('Tu planeación (desliza la tabla horizontalmente)'),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    dataRowMinHeight: 60,
                    dataRowMaxHeight: double.infinity,
                    columns: const [
                      DataColumn(label: Text('Día')),
                      DataColumn(label: Text('Desayuno')),
                      DataColumn(label: Text('Almuerzo')),
                      DataColumn(label: Text('Cena')),
                      DataColumn(label: Text('Merienda')),
                    ],
                    rows: plan
                        .map(
                          (fila) => DataRow(
                            cells: AlimentacionService.columnas
                                .map(
                                  (key) => DataCell(
                                    SizedBox(
                                      width: key == 'dia' ? 85 : 180,
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                          vertical: 8,
                                        ),
                                        child: Text(fila[key]!),
                                      ),
                                    ),
                                  ),
                                )
                                .toList(),
                          ),
                        )
                        .toList(),
                  ),
                ),
              ],
              const SizedBox(height: 20),
              const Text(
                'Orientación general generada por IA; puede contener '
                'errores. Revisa los ingredientes si tienes alergias. '
                'Para necesidades médicas, consulta a un nutricionista.',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
