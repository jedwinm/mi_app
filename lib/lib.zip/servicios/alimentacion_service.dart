import 'dart:convert';

import 'package:http/http.dart' as http;

class AlimentacionService {
  // CONEXIÓN: URL de tu servidor, nunca la clave de OpenAI.
  // Configúrala al ejecutar con --dart-define=API_URL=https://tu-servidor/plan
  static const apiUrl = String.fromEnvironment('API_URL');
  static const diasSemana = [
    'Lunes',
    'Martes',
    'Miércoles',
    'Jueves',
    'Viernes',
    'Sábado',
    'Domingo',
  ];
  static const columnas = ['dia', 'desayuno', 'almuerzo', 'cena', 'merienda'];

  Future<List<Map<String, String>>> generarPlan(
    Map<String, dynamic> brief,
  ) async {
    if (apiUrl.isEmpty) {
      throw Exception(
        'Configura API_URL con la dirección de tu servidor. '
        'Consulta CONEXION_CHATGPT.md.',
      );
    }
    final response = await http
        .post(
          Uri.parse(apiUrl),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode(brief),
        )
        .timeout(const Duration(seconds: 90));

    if (response.statusCode != 200) {
      throw Exception(
        'El servidor no pudo generar el plan '
        '(código ${response.statusCode}). Intenta nuevamente.',
      );
    }
    final data = jsonDecode(utf8.decode(response.bodyBytes));
    final dias = data is Map ? data['dias'] : null;
    if (dias is! List || dias.length != brief['dias']) {
      throw const FormatException(
        'La respuesta no tiene los días solicitados.',
      );
    }
    return List.generate(dias.length, (index) {
      final fila = dias[index];
      if (fila is! Map ||
          columnas.any(
            (key) =>
                fila[key] is! String || (fila[key] as String).trim().isEmpty,
          ) ||
          fila['dia'] != diasSemana[index]) {
        throw const FormatException('El formato de la tabla no es válido.');
      }
      return {for (final key in columnas) key: fila[key] as String};
    });
  }
}
